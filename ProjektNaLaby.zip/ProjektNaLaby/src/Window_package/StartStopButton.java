package Window_package;

import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.JButton;

public class StartStopButton extends JButton {

	public StartStopButton() {
		super("START/STOP");
	}

}
