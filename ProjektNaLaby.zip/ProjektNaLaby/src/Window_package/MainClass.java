package Window_package;

public class MainClass {

	public MainClass() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		MainWindow frame = new MainWindow("Window");
		frame.setVisible(true);

	}

}
